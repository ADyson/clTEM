﻿namespace Framework.UI.Controls
{
    using System.Collections.Generic;
    using System.Windows.Interactivity;

    /// <summary>
    /// The triggers.
    /// </summary>
    public sealed class Triggers : List<TriggerBase>
    {
    }
}
