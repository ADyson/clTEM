﻿namespace Framework.UI.Controls
{
    using System.Collections.Generic;
    using System.Windows.Interactivity;

    /// <summary>
    /// The behaviours.
    /// </summary>
    public sealed class Behaviors : List<Behavior>
    {
    }
}
