﻿namespace Framework.UI.Controls
{
    /// <summary>
    /// The wizard animation.
    /// </summary>
    public enum WizardAnimation
    {
        Fade,
        Slide,
        FadeAndSlide
    }
}
