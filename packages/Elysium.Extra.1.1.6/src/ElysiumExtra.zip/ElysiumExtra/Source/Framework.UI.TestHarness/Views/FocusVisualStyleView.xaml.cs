﻿namespace Framework.UI.TestHarness.Views
{
    /// <summary>
    /// Interaction logic for FocusVisualStyleView.xaml
    /// </summary>
    public partial class FocusVisualStyleView
    {
        public FocusVisualStyleView()
        {
            InitializeComponent();
        }
    }
}
