﻿namespace Framework.UI.TestHarness.Views
{
    /// <summary>
    /// Interaction logic for ExpandersView.xaml
    /// </summary>
    public partial class ExpandersView
    {
        public ExpandersView()
        {
            InitializeComponent();
        }
    }
}
