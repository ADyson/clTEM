﻿namespace Framework.UI.TestHarness.Views
{
    /// <summary>
    /// Interaction logic for SeparatorsView.xaml
    /// </summary>
    public partial class SeparatorsView
    {
        public SeparatorsView()
        {
            InitializeComponent();
        }
    }
}
