﻿namespace Framework.UI.TestHarness.Views
{
    /// <summary>
    /// Interaction logic for PanelsView.xaml
    /// </summary>
    public partial class PanelsView
    {
        public PanelsView()
        {
            InitializeComponent();
        }
    }
}
