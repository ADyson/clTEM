﻿namespace Framework.UI.TestHarness.Views
{
    /// <summary>
    /// Interaction logic for AppBarView.xaml
    /// </summary>
    public partial class AppBarView
    {
        public AppBarView()
        {
            InitializeComponent();
        }
    }
}
