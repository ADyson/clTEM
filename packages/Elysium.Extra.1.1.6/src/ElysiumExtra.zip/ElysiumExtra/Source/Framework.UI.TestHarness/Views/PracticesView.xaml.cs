﻿namespace Framework.UI.TestHarness.Views
{
    /// <summary>
    /// Interaction logic for PracticesView.xaml
    /// </summary>
    public partial class PracticesView
    {
        public PracticesView()
        {
            InitializeComponent();
        }
    }
}
